# Собери ПК для учёбы

Интерактивная новела (Twine). Открывается через GitHub Pages: index.html.
Исходник для Twine: novella.twee (Twine 2.6+ → Library → Import).
